# Les Étoiles de Taounate — Application Android
Projet Android Studio prêt à compiler.

## Fonctionnalités
- 81 joueurs importés depuis le fichier Excel fourni.
- Recherche par joueur, parent ou téléphone.
- Filtre par catégorie.
- Tableau de bord : nombre de joueurs, catégories et paiements.
- Ajout, modification et suppression.
- Données conservées localement sur le téléphone.
- Fonctionnement hors ligne.

## Générer l'APK
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Android Studio synchroniser Gradle.
3. Menu `Build > Build APK(s)`.
4. L'APK sera généré dans `app/build/outputs/apk/debug/`.

## Remarque
Le fichier Excel source n'est pas modifié. Les données initiales sont intégrées dans `app/src/main/assets/players.json`.
